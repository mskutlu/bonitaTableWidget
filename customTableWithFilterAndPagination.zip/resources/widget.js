(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customCustomTablePagination', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function LastTableCtrl($scope, $filter) {

    this.isArray = Array.isArray;
    $scope.filterList = [];
    this.isClickable = function () {
      return $scope.properties.isBound('selectedRow');
    };
    
    this.selectRow = function (row) {
      if (this.isClickable()) {
        $scope.properties.selectedRow = row;
      }
    };
    
   $scope.$watch('search', function (term) {
      var obj = term;
      
      $scope.filterList = $filter('filter')($scope.properties.content, obj);
      $scope.currentPage = 1;
    }); 
   
    $scope.sort = function(name)
    {
        console.log(name);
        $scope.sortKey = name;
        $scope.reverse = !$scope.reverse;
    };
    
    this.isSelected = function(row) {
      return angular.equals(row, $scope.properties.selectedRow);
    };
    
  },
      template: '<div class="table-responsive">\r\n    <input \r\n    class="form-control" \r\n    ng-model = "search" \r\n    type="text" placeholder="Search">\r\n    <br>\r\n<table class="table table-striped" ng-class="{\'table-hover\': ctrl.isClickable()}">\r\n        <thead>\r\n            <tr>\r\n                <th ng-repeat="header in properties.headers"  ng-click="sort(properties.columnsKey[$index])">\r\n                    {{ header | uiTranslate }}\r\n                    <span class="glyphicon sort-icon" ng-show="sortKey==properties.columnsKey[$index]" ng-class="{\'glyphicon-chevron-up\':reverse, \'glyphicon-chevron-down\':!reverse}"></span>\r\n                </th>\r\n            </tr>\r\n        </thead>\r\n        <tbody ng-if="ctrl.isArray(properties.content) && ctrl.isArray(properties.columnsKey)">\r\n            <tr dir-paginate="row in filterList.length == undefined ? properties.content : filterList | orderBy:sortKey:reverse | itemsPerPage: properties.itemsPerPage | filter : search" ng-click="ctrl.selectRow(row)" ng-class="{\'info\': ctrl.isSelected(row)}" pagination-id="people">\r\n                <td ng-repeat="column in properties.columnsKey track by $index" >\r\n                    {{ $eval(column, row) | uiTranslate }}\r\n                </td>\r\n            </tr>\r\n        </tbody>\r\n        <tbody ng-if="ctrl.isArray(properties.content) && !ctrl.isArray(properties.columnsKey)">\r\n            <tr dir-paginate="row in properties.content" ng-click="ctrl.selectRow(row)" ng-class="{\'info\': ctrl.isSelected(row)}">\r\n                <td> {{ row | uiTranslate }} </td>\r\n            </tr>\r\n        </tbody>\r\n    </table>\r\n    <dir-pagination-controls pagination-id="people" class="pull-right"></dir-pagination-controls>\r\n</div>\r\n'
    };
  });
